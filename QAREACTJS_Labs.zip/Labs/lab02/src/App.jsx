import FirstComponent from './FirstComponent';
import Image from './Image';
import Exp from './Exp';
import './App.css';

function App() {
  return (
    <div className="App">
      <FirstComponent />
      <Image />
      <Exp />
    </div>
  );
}

export default App;
