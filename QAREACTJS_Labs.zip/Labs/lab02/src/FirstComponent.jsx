const FirstComponent = () => {

    return ( 
        <div className="content">
            <h1>My First Webpage</h1>
            <p>This will look Great</p>
        </div>
     );
}
 
export default FirstComponent;