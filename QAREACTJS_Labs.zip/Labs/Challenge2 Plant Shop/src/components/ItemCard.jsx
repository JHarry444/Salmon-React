import styles from './ItemCard.module.css'
import { useState } from 'react'

const ItemCard = ({ id, name, price, imageUrl }) => {
  const [ isItemInCart, setIsItemInCart ] = useState(false)
  
  function handleButtonClick() {
    setIsItemInCart((previous) => !previous)
  }


  return (
    <div className={styles.wrapper}>
      <img src={imageUrl} width={200} height={250} alt={name} title={name} />
      <h3 className={styles.name}>{name}</h3>
      <p className={styles.price}>£{price.toFixed(2)}</p>
      <button
        onClick={handleButtonClick}
        className={styles[isItemInCart ? 'remove-from-cart' : 'add-to-cart']}
        >
        {isItemInCart ? 'In cart' : 'Add to cart'}
      </button>
    </div>
  )
}

export default ItemCard