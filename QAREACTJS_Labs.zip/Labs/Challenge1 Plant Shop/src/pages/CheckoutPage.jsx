import CheckoutItem from '../components/CheckoutItem'
import styles from './CheckoutPage.module.css'

const CheckoutPage = ({ itemsData }) => {

  return (
    <div>
      <h1 className={styles.header}>Checkout</h1>
      <div className={styles['items-wrapper']}>
      <>{itemsData.map((item) => <CheckoutItem {...item} key={item.id} />)}</>
      </div>
      <p className={styles.total}><b>Total: </b>£0.00</p>

      <button  className={styles['checkout-button']}>
        Checkout
      </button>

    </div>
  )
}

export default CheckoutPage