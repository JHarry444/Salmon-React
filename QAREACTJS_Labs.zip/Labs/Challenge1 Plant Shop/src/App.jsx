import { useEffect, useState } from "react"
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Navbar from "./components/Navbar"
import HomePage from "./pages/HomePage"
import ItemsPage from "./pages/ItemsPage"
import CheckoutPage from "./pages/CheckoutPage"
import itemsData from './itemsData.json';


function App() {

  return (
      <BrowserRouter>
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/items" element={<ItemsPage itemsData={itemsData} />} />
            <Route path="/checkout" element={<CheckoutPage itemsData={itemsData}/>} />
          </Routes>
        </main>
      </BrowserRouter>

  )
}

export default App
