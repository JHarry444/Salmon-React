export default function AboutPage() {
    return (
        <div>
            <h2>This is the about Page</h2>
            <p>Some helpful information</p>
        </div>
    )
}