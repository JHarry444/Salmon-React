import { useContext } from 'react'
import { CartContext } from '../context/cart'
import CheckoutItem from '../components/CheckoutItem'
import { useNavigate } from "react-router-dom";
import styles from './CheckoutPage.module.css'

function CheckoutPage ()  {
  const { itemIds, getItemById, calculateTotal, emptyCart } = useContext(CartContext)
  const navigate = useNavigate();

  const isCartEmpty = !itemIds.length
  
    const handleCheckout = () => {
      alert('Thank you for shopping with us!')
    
      let order_items = [];
      for (let i = 0; i < itemIds.length; i++) {
        order_items.push(getItemById(itemIds[i]));
      }
      let order = {
        order_items,
        order_total: calculateTotal()
      }
        
      fetch('http://localhost:8000/orders/', {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      }).then(() => {
        emptyCart();
      }).then(() => {
        navigate('/');
      })
    }

  return (
    <div>
      <h1 className={styles.header}>Checkout</h1>
      <div className={styles['items-wrapper']}>
        {isCartEmpty ?
          <p>Your cart is empty!</p>
          : <>{itemIds.map((id) => <CheckoutItem {...getItemById(id)} key={id} />)}</>
        }
      </div>
      <p className={styles.total}><b>Total: </b>£{calculateTotal().toFixed(2)}</p>

      {!isCartEmpty && (
        <button onClick={handleCheckout} className={styles['checkout-button']}>
          Checkout
        </button>
      )}
    </div>
  )
}

export default CheckoutPage